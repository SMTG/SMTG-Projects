from django.apps import AppConfig


class TeycoConfig(AppConfig):
    name = 'teyco'
